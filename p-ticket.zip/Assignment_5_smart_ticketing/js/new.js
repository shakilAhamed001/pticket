document.getElementById('continue').addEventListener('click', function(){
    location.href = 'index.html';
})